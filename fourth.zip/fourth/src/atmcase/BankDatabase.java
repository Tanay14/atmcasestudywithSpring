package atmcase;

import java.util.ResourceBundle;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class BankDatabase {
	

	   @Autowired
	   private MyDatabase x;
	     
	  
	   public BankDatabase() throws Exception
	   {	      System.out.println("BankDatabase obj");
		  ResourceBundle r = ResourceBundle.getBundle("hello");  
	   } 
	 public void checkjdbctemp() {
		 System.out.println(x==null);
		 x.checkjdbctemp();
		// TODO Auto-generated method stub

	}
	   public int authenticateUser( Account c )
	   {
	      // attempt to retrieve the account with the account number
	      int status  = x.getAccount( c );

	      return status;
	   } // end method authenticateUser

	   

	public boolean updateDb(Account c) {
		// TODO Auto-generated method stub
		
		boolean status = x.updateAccount(c);
		
		return status;
	}



	public boolean updatePin(Account c) {
		boolean status = x.updatePin(c);
		return status;
	}


}
