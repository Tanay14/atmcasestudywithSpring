package atmcase;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class MyDatabase {

	@Autowired
	private JdbcTemplate t;
	
	public MyDatabase(){
		System.out.println("JDBCBasedAccount");
	}
	public void checkjdbctemp() {
		System.out.println(t==null);
	}
	
	public int getAccount(Account c) {
				
		String sql="select * from accinfo where accountNumber=?";
		Object params[]= { c.getAccountNumber()};
		Account acc=null;
		try {
			acc = t.queryForObject(sql, params,new BeanPropertyRowMapper<Account>(Account.class));
		} catch (DataAccessException e1) {
			e1.printStackTrace();
			
		}
		if( acc != null)
		{		
				if(acc.validatePIN(c.getPin()))
				{
					
					c.setTotalBalance(acc.getTotalBalance());
					return 1; //everything is ok
					
				}
				else {
					return 2;//accno wrong
				}
			
		}
		
		return 3; // pin was wrong
	}


	public boolean updateAccount(Account c) {
		/*this.TranceDb(c);*/
		String sql="update accinfo  set totalBalance =? where accountNumber = ?";
		Object params[]= { c.getTotalBalance(),c.getAccountNumber()};
		int ra =t.update(sql,params); 
		return  ra > 0 ;
	}


	public boolean updatePin(Account c) {		
		String sql="update accinfo  set pin =? where accountNumber = ?";
		Object params[]= { c.getPin(),c.getAccountNumber()};
		int ra =t.update(sql,params); 
		return  ra > 0 ;
	}

}
